// project-ui.js
// UI for managing TileForge Projects (uses ProjectStore)

(function(){
  const state = {
    currentProject: null, // { id, name }
    expandedFilesPanels: new Set(), /* updated by Cascade: preserve expanded state */
    projectOrder: [], /* updated by Cascade: stable ordering of projects */
  };

  // Modal helpers (replace browser dialogs)
  function alertModal(message, type = 'info', title = null) {
    if (window.Modal && typeof Modal.alert === 'function') {
      Modal.alert(message, type, title);
    } else {
      window.alert(message);
    }
  }

  // Open a dropdown (modal) to choose a project, then open the Locale picker and save into that project
  async function onNewWithProjectPicker() {
    try {
      // Load all projects for selection
      const items = await ProjectStore.list();
      if (!items || items.length === 0) {
        // If no projects exist, create one via ensureProjectContext, then continue
        const ctx = await ensureProjectContext();
        return onManageLocales(ctx.id);
      }

      // Build select HTML (no inline styles; themed classes)
      const optionsHtml = items.map(p => `<option value="${p.id}">${p.name}</option>`).join('');
      const content = `
        <div class="tf-field">
          <label class="tf-label" for="__tfProjectSelect">Choose a project to save the new file:</label>
          <div class="tf-select-wrap">
            <select id="__tfProjectSelect" class="tf-select">
              ${optionsHtml}
            </select>
          </div>
        </div>`;

      const projectId = await new Promise((resolve, reject) => {
        if (window.Modal && typeof Modal.confirm === 'function') {
          const modal = Modal.confirm({
            title: 'Select Project',
            content,
            confirmText: 'Continue',
            cancelText: 'Cancel',
            onConfirm: () => {
              const sel = document.getElementById('__tfProjectSelect');
              resolve(sel && sel.value ? sel.value : null);
            },
            onCancel: () => reject(new Error('Canceled'))
          });
          modal.show();
        } else {
          // Fallback to prompt
          const nameList = items.map(p => p.name).join(', ');
          const chosen = window.prompt('Enter project name to save into:\n' + nameList, items[0].name);
          if (chosen === null) return reject(new Error('Canceled'));
          const found = items.find(p => p.name.toLowerCase() === String(chosen).trim().toLowerCase());
          resolve(found ? found.id : items[0].id);
        }
      });

      if (!projectId) throw new Error('Canceled');
      await onManageLocales(projectId);
    } catch (e) {
      if (e && e.message === 'Canceled') return;
      console.error(e);
      alertModal('New file flow failed', 'error');
    }
  }

  // Clone the currently active/working CSV as a new file in the current project (append -clone)
  async function onCloneActiveFile() {
    try {
      const ctx = await ensureProjectContext();
      const proj = await ProjectStore.get(ctx.id);
      if (!proj) throw new Error('Project not found');

      // Determine working rows and base active name
      const workingRows = Array.isArray(window.currentCsvData) ? window.currentCsvData : [];
      const currentActive = (proj.data && (proj.data.activeCsv || (proj.data.csvs && proj.data.csvs[0] && proj.data.csvs[0].name))) || 'current.csv';

      // Decide extension based on generator availability and current active name
      const hasCsvGen = (typeof generateCSVContent === 'function');
      const preferredExt = hasCsvGen ? '.csv' : '.json';
      const base = currentActive.replace(/\.(csv|json)$/i, '');
      const ext = /\.(csv|json)$/i.test(currentActive) ? currentActive.match(/\.(csv|json)$/i)[0].toLowerCase() : preferredExt;

      // Build unique clone filename: base-clone.ext, then base-clone-2.ext, etc.
      proj.data = proj.data || { csvs: [], activeCsv: null, image: null, template: 'toh', settings: {} };
      const csvs = Array.isArray(proj.data.csvs) ? proj.data.csvs : (proj.data.csvs = []);
      const existing = new Set(csvs.map(f => (f && f.name ? f.name.toLowerCase() : '')));
      let cloneName = `${base}-clone${ext}`;
      if (existing.has(cloneName.toLowerCase())) {
        let n = 2;
        while (existing.has(`${base}-clone-${n}${ext}`.toLowerCase())) n++;
        cloneName = `${base}-clone-${n}${ext}`;
      }

      // Generate file text
      let entryText = '';
      if (ext === '.csv' && hasCsvGen) {
        entryText = generateCSVContent(workingRows);
      } else {
        entryText = JSON.stringify(workingRows);
      }

      // Append as a new file; do not change activeCsv
      csvs.push({ name: cloneName, text: entryText });
      await ProjectStore.saveSnapshot(ctx.id, proj.data);
      refreshList();
      if (window.showToast) window.showToast(`Cloned as ${cloneName}`, 'success'); else alertModal(`Cloned as ${cloneName}`, 'success');
    } catch (e) {
      if (e && e.message === 'Canceled') return;
      console.error(e);
      alertModal('Clone failed', 'error');
    }
  }

  function downloadTextFile(filename, text, mime) {
    try {
      const blob = new Blob([text], { type: mime || 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename || 'download.txt';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error(e);
      alertModal('Failed to export file', 'error');
    }
  }

  function collectLocalesFromRows(rows) {
    if (!Array.isArray(rows)) return [];
    const set = new Set();
    rows.forEach(r => {
      const loc = r.Locale || r.locale;
      if (loc) set.add(loc);
    });
    return Array.from(set).sort();
  }

  function mergeLocalesIntoRows(selectedLocales, baseRows) {
    const rows = Array.isArray(baseRows) ? [...baseRows] : [];
    const hasLocale = (rows, loc) => rows.some(r => (r.Locale || r.locale) === loc);
    selectedLocales.forEach(loc => {
      if (!hasLocale(rows, loc)) {
        rows.push({ Locale: loc, 'items/0/title': '', 'items/0/subtitle': '', 'items/0/narratorText': '' });
      }
    });
    // Keep rows sorted alphabetically by locale code to match Locale Manager ordering
    rows.sort((a, b) => {
      const la = String(a.Locale || a.locale || '').toUpperCase();
      const lb = String(b.Locale || b.locale || '').toUpperCase();
      return la.localeCompare(lb);
    });
    return rows;
  }

  async function onManageLocales(projectId) {
    try {
      if (!window.TileForgeLocalesUI || typeof window.TileForgeLocalesUI.open !== 'function') {
        return alertModal('Locale Picker UI not loaded.', 'warning');
      }
      // Preselect from current working data
      const preselect = collectLocalesFromRows(window.currentCsvData);
      window.TileForgeLocalesUI.open(function(selectedLocales) {
        // Merge selected locales into working set
        const merged = mergeLocalesIntoRows(selectedLocales, window.currentCsvData);
        window.currentCsvData = merged;
        // Persist as a new CSV instance in the project and set active
        (async () => {
          try {
            const proj = await ProjectStore.get(projectId);
            if (!proj || !proj.data) throw new Error('Project not found');
            const csvs = Array.isArray(proj.data.csvs) ? proj.data.csvs : (proj.data.csvs = []);
            // Ask user for the CSV name (default suggested)
            const stamp = new Date();
            const pad = (n)=> String(n).padStart(2,'0');
            const defaultName = `locales-${stamp.getFullYear()}${pad(stamp.getMonth()+1)}${pad(stamp.getDate())}-${pad(stamp.getHours())}${pad(stamp.getMinutes())}${pad(stamp.getSeconds())}.csv`;
            let inputName = await promptAsync('Name your new CSV', defaultName, { title: 'New CSV Name' }).catch(() => null);
            if (!inputName) return; // user canceled
            inputName = inputName.trim();
            if (!inputName.toLowerCase().endsWith('.csv')) inputName += '.csv';
            // Ensure unique name within project
            const existing = new Set(csvs.map(c => c.name.toLowerCase()));
            let name = inputName;
            if (existing.has(name.toLowerCase())) {
              const base = name.replace(/\.csv$/i, '');
              let i = 1;
              while (existing.has(`${base}-${i}.csv`.toLowerCase())) i++;
              name = `${base}-${i}.csv`;
            }
            csvs.push({ name, rows: merged });
            // Serialize merged rows to stored file shape expected by loader
            // Loader expects entries like { name, text }
            let storedEntry;
            if (typeof generateCSVContent === 'function') {
              const text = generateCSVContent(merged);
              storedEntry = { name, text };
            } else {
              // Fallback: store JSON if CSV generator not present
              const jsonName = name.replace(/\.csv$/i, '.json');
              storedEntry = { name: jsonName, text: JSON.stringify(merged) };
            }
            // Replace the provisional push with the proper entry
            csvs.pop();
            csvs.push(storedEntry);
            proj.data.activeCsv = storedEntry.name; /* updated by Cascade */
            await ProjectStore.update(proj.id, proj);
            // Refresh UI list and load the new active file to reflect immediately
            if (typeof refreshList === 'function') refreshList();
            if (typeof onSetActiveFile === 'function') onSetActiveFile(proj.id, storedEntry.name);
            if (typeof window.setActiveLocalesForPreview === 'function') {
              window.setActiveLocalesForPreview(selectedLocales);
            }
            if (typeof window.renderLocaleGroups === 'function') {
              window.renderLocaleGroups(merged);
            }
            if (window.showToast) window.showToast(`Created new CSV "${name}" and set active`, 'success');
          } catch (err) {
            console.error(err);
            alertModal('Failed to create CSV for selected locales', 'error');
          }
        })();
      }, preselect);
    } catch (e) {
      console.error(e);
      alertModal('Failed to manage locales', 'error');
    }
  }

  function confirmAsync(message, options = {}) {
    return new Promise(resolve => {
      if (window.Modal && typeof Modal.confirm === 'function') {
        const modal = Modal.confirm({
          content: message,
          ...options,
          onConfirm: () => resolve(true),
          onCancel: () => resolve(false)
        });
        modal.show();
      } else {
        resolve(window.confirm(message));
      }
    });
  }

  function promptAsync(message, defaultValue = '', options = {}) {
    return new Promise((resolve, reject) => {
      if (window.Modal && typeof Modal.prompt === 'function') {
        const modal = Modal.prompt({
          title: options.title || 'Input Required',
          message,
          defaultValue,
          onConfirm: (val) => resolve(val),
          onCancel: () => reject(new Error('Canceled')),
        });
        modal.show();
      } else {
        const v = window.prompt(message, defaultValue);
        if (v === null) reject(new Error('Canceled')); else resolve(v);
      }
    });
  }

  function getCurrentTemplate() {
    const active = document.querySelector('.template-option.active');
    return active ? active.getAttribute('data-template') : 'toh';
  }

  function getEnabledSections() {
    const checks = document.querySelectorAll('.section-enabled');
    const result = {};
    checks.forEach(chk => {
      const key = chk.getAttribute('data-target');
      result[key] = chk.checked;
    });
    return result;
  }

  function buildSnapshotFromUI() {
    const data = {
      csvs: [],
      activeCsv: null, // updated by Cascade: start empty unless editor has data
      image: null, // future: capture uploaded image if available
      template: getCurrentTemplate(),
      settings: {
        enabledSections: getEnabledSections(),
      }
    };
    // Serialize currentCsvData only if rows exist
    if (Array.isArray(window.currentCsvData) && window.currentCsvData.length) {
      if (typeof generateCSVContent === 'function') {
        const csvText = generateCSVContent(window.currentCsvData);
        data.csvs.push({ name: 'current.csv', text: csvText });
        data.activeCsv = 'current.csv';
      } else {
        // fallback: store as JSON
        data.csvs.push({ name: 'current.json', text: JSON.stringify(window.currentCsvData) });
        data.activeCsv = 'current.json';
      }
    }
    return data;
  }

  function loadSnapshotIntoUI(project) {
    try {
      const data = project.data || {};
      // Load CSV into currentCsvData
      const active = data.activeCsv || (data.csvs && data.csvs[0] && data.csvs[0].name);
      let csvRows = [];
      let activeEntry = null; /* updated by Cascade: track active entry for persistence */
      if (active && Array.isArray(data.csvs)) {
        const entry = data.csvs.find(f => f.name === active) || data.csvs[0];
        if (entry) {
          activeEntry = entry; /* updated by Cascade */
          if (entry.name.endsWith('.csv')) {
            // Parse CSV quickly via existing CSV loader if present
            if (typeof window.processCsvText === 'function') {
              csvRows = window.processCsvText(entry.text);
            } else {
              // Very basic CSV parser for fallback
              csvRows = fallbackParseCSV(entry.text);
            }
          } else if (entry.name.endsWith('.json')) {
            csvRows = JSON.parse(entry.text);
          }
        }
      }
      if (Array.isArray(csvRows)) {
        window.currentCsvData = csvRows;
        if (typeof renderLocaleGroups === 'function') renderLocaleGroups(csvRows);
        // Persist last loaded CSV for startup restore when toggle is enabled
        // updated by Cascade: only persist when the active entry is a CSV
        try {
          if (activeEntry && typeof activeEntry.name === 'string' && /\.csv$/i.test(activeEntry.name) && typeof activeEntry.text === 'string') {
            localStorage.setItem('tileforge-last-csv', activeEntry.text);
            localStorage.setItem('tileforge-last-csv-name', activeEntry.name);
          }
        } catch (_) { /* no-op */ }
        // Reflect active CSV into the localized preview status pill
        try {
          const activeName = active || '';
          if (typeof updateFileInfo === 'function' && activeName) {
            updateFileInfo('CSV', activeName, csvRows.length || 0);
          } else {
            const nameEl = document.getElementById('activeCsvName');
            if (nameEl) {
              nameEl.textContent = activeName || '—';
              const pill = nameEl.parentElement; if (pill && pill.setAttribute) pill.setAttribute('title', activeName ? `Currently active CSV: ${activeName}` : 'No active CSV selected');
            }
          }
          // Ensure localized export button reflects data availability
          if (typeof updateLocalizedExportState === 'function') {
            updateLocalizedExportState(Array.isArray(csvRows) && csvRows.length > 0);
          }
        } catch (e) { /* no-op */ }
      }

      // Apply template selection visually
      const activeTpl = data.template || 'toh';
      document.querySelectorAll('.template-option').forEach(el => {
        el.classList.toggle('active', el.getAttribute('data-template') === activeTpl);
      });

      // Apply enabled sections
      const settings = data.settings || {};
      const enabled = settings.enabledSections || {};
      document.querySelectorAll('.section-enabled').forEach(chk => {
        const key = chk.getAttribute('data-target');
        if (key in enabled) chk.checked = !!enabled[key];
      });
    } catch (e) {
      console.error('Failed to load project into UI', e);
      alertModal('Failed to load project. See console for details.', 'error');
    }
  }

  function fallbackParseCSV(text) {
    // Very minimal CSV -> rows of objects using first row as headers
    const lines = text.split(/\r?\n/).filter(Boolean);
    if (lines.length === 0) return [];
    const headers = lines[0].split(',').map(h => h.replace(/^"|"$/g, ''));
    const rows = [];
    for (let i = 1; i < lines.length; i++) {
      const cols = parseCsvLine(lines[i]);
      const obj = {};
      headers.forEach((h, idx) => obj[h] = cols[idx] || '');
      rows.push(obj);
    }
    return rows;
  }

  function parseCsvLine(line) {
    const result = [];
    let i = 0, cur = '', inQ = false;
    while (i < line.length) {
      const ch = line[i++];
      if (inQ) {
        if (ch === '"') {
          if (line[i] === '"') { cur += '"'; i++; }
          else inQ = false;
        } else cur += ch;
      } else {
        if (ch === ',') { result.push(cur); cur = ''; }
        else if (ch === '"') { inQ = true; }
        else cur += ch;
      }
    }
    result.push(cur);
    return result;
  }

  async function ensureProjectContext() {
    if (state.currentProject && state.currentProject.id) return state.currentProject;
    const name = await promptAsync('Project name:');
    if (!name) throw new Error('Canceled');
    const description = await promptAsync('Short description (optional):', '');
    const rec = await window.ProjectStore.create(name, buildSnapshotFromUI(), description || '');
    state.currentProject = { id: rec.id, name: rec.name };
    refreshList();
    return state.currentProject;
  }

  async function onNew() {
    const choice = await confirmAsync(
      'Start a new project. Choose how to initialize it:\n\n• Use Current State — copy what\'s in the editor now into the project\n• Start Blank — create an empty project you can build from',
      { confirmText: 'Use Current State', cancelText: 'Start Blank' }
    );
    const name = await promptAsync('Project name:', '', { title: 'Name Your Project' });
    if (!name) return;
    const description = await promptAsync('Short description (optional):', '', { title: 'Project Description' });
    const data = choice ? buildSnapshotFromUI() : { csvs: [], activeCsv: null, image: null, template: 'toh', settings: { enabledSections: { title: true, subtitle: true, narrator: true } } };
    const rec = await ProjectStore.create(name, data, description || '');
    state.currentProject = { id: rec.id, name: rec.name };
    refreshList();
    alertModal('Project created', 'success');
  }

  async function onSave(silent = false) {
    try {
      const ctx = await ensureProjectContext();
      // Load existing project to preserve current files and active CSV name
      const proj = await ProjectStore.get(ctx.id);
      if (!proj) throw new Error('Project not found');

      // Determine working rows and active file name
      const workingRows = Array.isArray(window.currentCsvData) ? window.currentCsvData : [];
      let activeName = (proj.data && (proj.data.activeCsv || (proj.data.csvs && proj.data.csvs[0] && proj.data.csvs[0].name))) || 'current.csv';

      // Ensure data structure exists
      proj.data = proj.data || { csvs: [], activeCsv: activeName, image: null, template: 'toh', settings: {} };

      // Update template and enabled sections from current UI state
      proj.data.template = getCurrentTemplate();
      proj.data.settings = proj.data.settings || {};
      proj.data.settings.enabledSections = getEnabledSections();

      // Generate file text based on available generator
      let entryName = activeName;
      let entryText = '';
      const hasCsvGen = (typeof generateCSVContent === 'function');
      if (hasCsvGen) {
        entryText = generateCSVContent(workingRows);
        // Prefer .csv extension when we can generate CSV
        if (!/\.csv$/i.test(entryName)) entryName = entryName.replace(/\.json$/i, '.csv');
      } else {
        entryText = JSON.stringify(workingRows);
        // Fallback to .json when CSV generator is unavailable
        if (!/\.json$/i.test(entryName)) entryName = entryName.replace(/\.csv$/i, '.json');
      }

      // Find existing active entry and update, or add a new one
      const csvs = Array.isArray(proj.data.csvs) ? proj.data.csvs : (proj.data.csvs = []);
      const idx = csvs.findIndex(f => f.name === entryName);
      if (idx >= 0) {
        csvs[idx].text = entryText;
      } else {
        csvs.push({ name: entryName, text: entryText });
      }
      proj.data.activeCsv = entryName;

      // Persist changes without renaming files
      await ProjectStore.saveSnapshot(ctx.id, proj.data);
      refreshList();
      if (!silent) {
        if (window.showToast) window.showToast('Project saved', 'success'); else alertModal('Project saved', 'success');
      }
      // Mark export ready after successful save
      try { window.dispatchEvent(new Event('tileforge:file-saved')); } catch (_) {}
    } catch (e) {
      if (e && e.message === 'Canceled') return;
      console.error(e);
      alertModal('Save failed', 'error');
    }
  }

  async function onClone(projectId) {
    // If a specific projectId is provided (from list action), clone that project.
    if (projectId) {
      const proj = await ProjectStore.get(projectId);
      if (!proj) return;
      const newName = await promptAsync('Name for cloned project:', (proj.name || 'Project') + ' (Copy)');
      if (!newName) return;
      const rec = await ProjectStore.clone(projectId, newName);
      state.currentProject = { id: rec.id, name: rec.name };
      refreshList();
      alertModal('Project cloned', 'success');
      return;
    }
    // Otherwise, preserve prior behavior: clone current project or state
    if (!state.currentProject) {
      // allow clone from current state into a newly named project
      const name = await promptAsync('Clone to new project name:');
      if (!name) return;
      const rec = await ProjectStore.create(name, buildSnapshotFromUI());
      state.currentProject = { id: rec.id, name: rec.name };
      refreshList();
      alertModal('Cloned to new project', 'success');
      return;
    }
    const newName = await promptAsync('Name for cloned project:', state.currentProject.name + ' (Copy)');
    if (!newName) return;
    const rec = await ProjectStore.clone(state.currentProject.id, newName);
    state.currentProject = { id: rec.id, name: rec.name };
    refreshList();
    alertModal('Project cloned', 'success');
  }

  // Generic collapsible section helper
  function setupCollapsible({ sectionId, buttonId, storageKey }) {
    const container = document.getElementById(sectionId);
    const btn = document.getElementById(buttonId);
    if (!container || !btn) return;
    // Target the immediate heading for larger click area
    const header = container.querySelector(':scope > h3, :scope > h4');
    const applyCollapsed = (collapsed) => {
      container.classList.toggle('collapsed', !!collapsed);
      btn.setAttribute('aria-expanded', String(!collapsed));
      if (header) header.setAttribute('aria-expanded', String(!collapsed));
      const icon = btn.querySelector('i');
      if (icon) {
        icon.classList.toggle('fa-chevron-up', !collapsed);
        icon.classList.toggle('fa-chevron-down', !!collapsed);
      }
    };
    const stored = localStorage.getItem(storageKey);
    const initialCollapsed = stored === 'true';
    applyCollapsed(initialCollapsed);
    // Central toggle
    const toggle = () => {
      const nowCollapsed = !container.classList.contains('collapsed');
      localStorage.setItem(storageKey, String(nowCollapsed));
      applyCollapsed(nowCollapsed);
    };
    // Keep existing button behavior but stop propagation so header doesn't double-toggle
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      toggle();
    });
    // Enlarge target: allow clicking the entire header row
    if (header) {
      // Make header focusable and button-like for a11y
      if (!header.hasAttribute('tabindex')) header.setAttribute('tabindex', '0');
      if (!header.hasAttribute('role')) header.setAttribute('role', 'button');
      header.addEventListener('click', (e) => {
        // Ignore clicks originating from the dedicated chevron button
        if (e.target && e.target.closest && e.target.closest(`#${buttonId}`)) return;
        toggle();
      });
      header.addEventListener('keydown', (e) => {
        // Activate on Enter or Space
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          toggle();
        }
      });
    }
  }

  function mountProjectsSection() {
    // List will be rendered by refreshList; set up collapsible behavior
    setupCollapsible({ sectionId: 'projectsSection', buttonId: 'projectsCollapseBtn', storageKey: 'TileForge_projects_collapsed' });
  }

  function initOnce() {
    if (window.__tfProjectsInit) return;
    window.__tfProjectsInit = true;
    bindToolbar();
    // Collapsibles
    mountProjectsSection();
    setupCollapsible({ sectionId: 'filtersSection', buttonId: 'filtersCollapseBtn', storageKey: 'TileForge_filters_collapsed' });
    setupCollapsible({ sectionId: 'templateSection', buttonId: 'templateCollapseBtn', storageKey: 'TileForge_template_collapsed' });
    setupCollapsible({ sectionId: 'toolsSection', buttonId: 'toolsCollapseBtn', storageKey: 'TileForge_tools_collapsed' });
    setupCollapsible({ sectionId: 'imageInfoPanel', buttonId: 'imageInfoCollapseBtn', storageKey: 'TileForge_image_collapsed' });
    refreshList();
    // Wire global readiness toggles for export button on active file row (no new classes)
    window.addEventListener('tileforge:file-dirty', () => {
      const btn = document.querySelector('.project-file-row.is-active .file-actions [data-act="export-file"]');
      if (btn) btn.setAttribute('data-ready', 'false');
    });
    window.addEventListener('tileforge:file-saved', () => {
      const btn = document.querySelector('.project-file-row.is-active .file-actions [data-act="export-file"]');
      if (btn) btn.setAttribute('data-ready', 'true');
    });
    // Convenience helpers for other modules/editors to signal state
    window.TileForge = window.TileForge || {};
    window.TileForge.markDirty = function() { try { window.dispatchEvent(new Event('tileforge:file-dirty')); } catch (_) {} };
    window.TileForge.markSaved = function() { try { window.dispatchEvent(new Event('tileforge:file-saved')); } catch (_) {} };
  }

  async function refreshList() {
    const listEl = document.getElementById('projectsList');
    if (!listEl) return;
    let items = await ProjectStore.list();
    // Maintain stable order irrespective of updatedAt changes
    if (!Array.isArray(state.projectOrder) || state.projectOrder.length === 0) {
      state.projectOrder = items.map(p => p.id);
    } else {
      // Remove any IDs that no longer exist
      const existingIds = new Set(items.map(p => p.id));
      state.projectOrder = state.projectOrder.filter(id => existingIds.has(id));
      // Append any new IDs to end
      items.forEach(p => { if (!state.projectOrder.includes(p.id)) state.projectOrder.push(p.id); });
    }
    const pos = new Map(state.projectOrder.map((id, i) => [id, i]));
    items = items.slice().sort((a, b) => (pos.get(a.id) ?? 0) - (pos.get(b.id) ?? 0));
    listEl.innerHTML = items.map(p => {
      const isActive = state.currentProject && state.currentProject.id === p.id;
      const date = new Date(p.updatedAt || p.createdAt).toLocaleString();
      const fileCount = (p.data && Array.isArray(p.data.csvs)) ? p.data.csvs.length : 0;
      const activeCsv = p.data && p.data.activeCsv ? p.data.activeCsv : (fileCount && p.data.csvs[0].name) || '';
      const isExpanded = state.expandedFilesPanels.has(p.id);
      return `
        <div class="project-item${isActive ? ' active' : ''}">
          <div class="project-meta">
            <div class="project-name">${p.name}</div>
            <div class="project-desc">${p.description || ''}</div>
            <div class="project-date">${date}</div>
          </div>
          <div class="project-actions">
            <button class="preset-apply-btn badge-btn" data-act="load" data-id="${p.id}" title="Load Project" aria-label="Load Project"><i class="fas fa-folder-open" aria-hidden="true"></i></button>
            <button class="preset-apply-btn badge-btn" data-act="clone" data-id="${p.id}" title="Clone Project" aria-label="Clone Project"><i class="fas fa-clone" aria-hidden="true"></i></button>
            <button class="preset-apply-btn badge-btn" data-act="delete" data-id="${p.id}" title="Delete Project" aria-label="Delete Project"><i class="fas fa-trash" aria-hidden="true"></i></button>
            <button class="files-toggle" data-act="toggle-files" data-id="${p.id}" aria-expanded="${isExpanded}"><span class="chev">${isExpanded ? '▼' : '►'}</span> Files (${fileCount})</button>
          </div>
          <div class="project-files" data-files-for="${p.id}" style="display:${isExpanded ? 'block' : 'none'};">
            <div class="project-files-header">
              <div class="project-files-actions">
                <button class="preset-apply-btn file-badge-btn" data-act="add-file" data-id="${p.id}" title="Add CSV" aria-label="Add CSV">
                  <i class="fas fa-file-upload" aria-hidden="true"></i>
                </button>
                <button class="preset-apply-btn file-badge-btn" data-act="manage-locales" data-id="${p.id}" title="Create New" aria-label="Create New">
                  <i class="fas fa-plus-circle" aria-hidden="true"></i>
                </button>
              </div>
            </div>
            <div class="project-files-list">
              ${(p.data?.csvs || []).map(f => `
                <div class="project-file-row${f.name === activeCsv ? ' is-active' : ''}" data-name="${f.name}" role="button" tabindex="0" aria-selected="${f.name === activeCsv}">
                  <span class="file-name">${f.name}</span>
                  <div class="file-actions">
                    <button class="preset-apply-btn file-badge-btn" data-act="rename-file" data-id="${p.id}" data-name="${f.name}" title="Rename File" aria-label="Rename File">
                      <i class="fas fa-edit" aria-hidden="true"></i>
                    </button>
                    <button class="preset-apply-btn file-badge-btn" data-act="gridpeek-file" data-id="${p.id}" data-name="${f.name}" title="GridPeek CSV" aria-label="GridPeek CSV Preview">
                      <i class="fas fa-table" aria-hidden="true"></i>
                    </button>
                    <button class="preset-apply-btn file-badge-btn" data-act="export-file" data-id="${p.id}" data-name="${f.name}" data-ready="true" title="Export to Iris CSV" aria-label="Export to Iris CSV">
                      <i class="fa fa-download" aria-hidden="true"></i>
                      <span>Export to Iris CSV</span>
                    </button>
                    <button class="preset-apply-btn file-badge-btn" data-act="remove-file" data-id="${p.id}" data-name="${f.name}" title="Remove File" aria-label="Remove File">
                      <i class="fas fa-trash" aria-hidden="true"></i>
                    </button>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        </div>`;
    }).join('');
    // Attach events
    listEl.querySelectorAll('button[data-act]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const act = btn.getAttribute('data-act');
        const id = btn.getAttribute('data-id');
        if (act === 'load') {
          const proj = await ProjectStore.get(id);
          if (proj) {
            state.currentProject = { id: proj.id, name: proj.name };
            loadSnapshotIntoUI(proj);
            refreshList();
          }
        } else if (act === 'clone') {
          onClone(id);
        } else if (act === 'delete') {
          if (await confirmAsync('Delete this project?', { type: 'destructive', confirmText: 'Delete', cancelText: 'Cancel' })) {
            await ProjectStore.remove(id);
            if (state.currentProject && state.currentProject.id === id) state.currentProject = null;
            // Keep order in sync after deletion
            if (Array.isArray(state.projectOrder)) {
              state.projectOrder = state.projectOrder.filter(pid => pid !== id);
            }
            refreshList();
          }
        } else if (act === 'toggle-files') {
          const panel = listEl.querySelector(`.project-files[data-files-for="${id}"]`);
          if (panel) {
            const isHidden = panel.style.display === 'none';
            panel.style.display = isHidden ? 'block' : 'none';
            // Update chevron and aria state
            const chev = btn.querySelector('.chev');
            if (chev) chev.textContent = isHidden ? '▼' : '►';
            btn.setAttribute('aria-expanded', String(isHidden));
            // Track expanded state so refreshList preserves it
            if (isHidden) state.expandedFilesPanels.add(id); else state.expandedFilesPanels.delete(id);
          }
        } else if (act === 'export-file') {
          const name = btn.getAttribute('data-name');
          try {
            // Silent pre-export save to capture latest state, but only if a project context exists
            // Avoid triggering project creation prompts during export
            if (typeof window.manualSave === 'function') {
              try {
                if (state && state.currentProject && state.currentProject.id) {
                  window.manualSave(true);
                }
              } catch (err) {
                if (window.showToast) window.showToast('Warning: Save before export failed, exporting anyway.', 'warning');
              }
            }
            const proj = await ProjectStore.get(id);
            if (!proj || !proj.data) return alertModal('Project not found', 'warning');
            const entry = (proj.data.csvs || []).find(f => f.name === name);
            if (!entry) return alertModal('File not found in project', 'error');
            const isCsv = /\.csv$/i.test(entry.name);
            // Track final exported filename for success message
            let exportedFileName = entry.name;
            // Prefer unified CSV export with BOM when helpers are available
            if (isCsv && typeof window.downloadCSVFile === 'function') {
              window.downloadCSVFile(entry.text || '', entry.name);
            } else if (!isCsv && typeof window.generateCSVContent === 'function' && typeof window.downloadCSVFile === 'function') {
              try {
                const rows = entry.text ? JSON.parse(entry.text) : [];
                const csv = window.generateCSVContent(rows);
                const csvName = entry.name.replace(/\.json$/i, '.csv');
                window.downloadCSVFile(csv, csvName);
                exportedFileName = csvName;
              } catch (jsonErr) {
                const mime = 'application/json;charset=utf-8';
                downloadTextFile(entry.name, entry.text || '', mime);
              }
            } else {
              const mime = isCsv ? 'text/csv;charset=utf-8' : 'application/json;charset=utf-8';
              downloadTextFile(entry.name, entry.text || '', mime);
            }
            // Notify success with green-accent modal (reuses Modal/alert helper)
            // updated by Cascade: remove emoji, rely on FA icon from Modal.alert()
            alertModal(`“${exportedFileName}” is forged and ready.<br><span class="modal-description">Delivered to your downloads.</span>`, 'success', 'File forged');
          } catch (e) {
            console.error(e);
            alertModal('Export failed', 'error');
          }
        } else if (act === 'add-file') {
          onAddFile(id);
        } else if (act === 'manage-locales') {
          onManageLocales(id);
        } else if (act === 'set-active-file') {
          const name = btn.getAttribute('data-name');
          onSetActiveFile(id, name);
        } else if (act === 'remove-file') {
          const name = btn.getAttribute('data-name');
          onRemoveFile(id, name);
        } else if (act === 'rename-file') {
          const name = btn.getAttribute('data-name');
          onRenameFile(id, name);
        } else if (act === 'gridpeek-file') {
          const name = btn.getAttribute('data-name');
          (async () => {
            try {
              const proj = await ProjectStore.get(id);
              if (!proj || !proj.data) return alertModal('Project not found', 'warning');
              const entry = (proj.data.csvs || []).find(f => f.name === name);
              if (!entry) return alertModal('File not found in project', 'error');
              let rows = [];
              if (/\.csv$/i.test(entry.name)) {
                if (typeof window.processCsvText === 'function') {
                  rows = window.processCsvText(entry.text || '');
                } else {
                  rows = fallbackParseCSV(entry.text || '');
                }
              } else if (/\.json$/i.test(entry.name)) {
                try { rows = JSON.parse(entry.text || '[]'); } catch (_) { rows = []; }
              }
              if (window.GridPeek && typeof window.GridPeek.open === 'function') {
                window.GridPeek.open({ rows, title: `GridPeek — ${entry.name}`, filename: entry.name });
              } else {
                if (window.Modal && typeof Modal.alert === 'function') {
                  Modal.alert('CSV Viewer (GridPeek) is not available. Make sure csv-viewer.js is loaded.', 'warning');
                } else {
                  alert('CSV Viewer (GridPeek) is not available.');
                }
              }
            } catch (e) {
              console.error(e);
              alertModal('Failed to open GridPeek preview', 'error');
            }
          })();
        }
      });
    });
    // Make entire file row clickable/keyboard-activatable to set active
    listEl.querySelectorAll('.project-file-row').forEach(row => {
      row.addEventListener('click', (e) => {
        if (e.target && e.target.closest('button')) return; // ignore clicks on buttons within the row
        const panel = row.closest('.project-files');
        const projectId = panel ? panel.getAttribute('data-files-for') : null;
        const name = row.getAttribute('data-name');
        if (projectId && name) onSetActiveFile(projectId, name);
      });
      row.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          const panel = row.closest('.project-files');
          const projectId = panel ? panel.getAttribute('data-files-for') : null;
          const name = row.getAttribute('data-name');
          if (projectId && name) onSetActiveFile(projectId, name);
        }
      });
    });

    // Attach drag-and-drop to each project's files container to add files directly
    listEl.querySelectorAll('.project-files[data-files-for]').forEach(panel => {
      const pid = panel.getAttribute('data-files-for');
      // Broaden drop targets to improve UX: accept drop on the whole project block as well
      const projectItem = panel.closest('.project-item');
      const dropTargets = [
        panel,
        panel.querySelector('.project-files-list'),
        panel.querySelector('.project-files-header'),
        projectItem
      ].filter(Boolean);
      dropTargets.forEach(zone => {
        // Avoid duplicate bindings across refreshes
        if (zone.__tfDndBound) return;
        zone.__tfDndBound = true;
        // Improve DnD reliability: handle dragenter explicitly
        zone.addEventListener('dragenter', (e) => {
          const dt = e.dataTransfer;
          const looksLikeFiles = (dt && dt.files && dt.files.length > 0) || (Array.from(dt?.types || []).includes('Files'));
          // Always prevent default so browser allows a drop on this zone
          e.preventDefault();
          e.stopPropagation();
          if (looksLikeFiles) zone.classList.add('drag-over');
        });
        zone.addEventListener('dragover', (e) => {
          // Always allow drop for this zone; highlight if likely files
          const dt = e.dataTransfer;
          const looksLikeFiles = (dt && dt.files && dt.files.length > 0) || (Array.from(dt?.types || []).includes('Files'));
          e.preventDefault();
          e.stopPropagation();
          try { if (dt) dt.dropEffect = 'copy'; } catch (_) {}
          if (looksLikeFiles) zone.classList.add('drag-over');
        });
        zone.addEventListener('dragleave', (e) => {
          e.preventDefault();
          e.stopPropagation();
          zone.classList.remove('drag-over');
        });
        zone.addEventListener('drop', async (e) => {
          e.preventDefault();
          e.stopPropagation();
          zone.classList.remove('drag-over');
          const dt = e.dataTransfer;
          let file = null;
          const files = dt && dt.files;
          if (files && files.length) {
            file = files[0];
          } else if (dt && dt.items && dt.items.length) {
            // Fallback for browsers providing DataTransferItemList
            for (let i = 0; i < dt.items.length; i++) {
              const item = dt.items[i];
              if (item.kind === 'file') { file = item.getAsFile(); break; }
            }
          }
          if (!file) return;
          try {
            await saveFileToProject(pid, file);
          } catch (err) {
            console.error(err);
            alertModal('Failed to add dropped file', 'error');
          }
        });
      });
    });
  }

  async function onAddFile(projectId) {
    try {
      const proj = await ProjectStore.get(projectId);
      if (!proj) return;
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.csv,text/csv';
      input.onchange = async () => {
        const file = input.files && input.files[0];
        if (!file) return;
        await saveFileToProject(projectId, file);
      };
      input.click();
    } catch (e) {
      console.error(e);
      alertModal('Failed to add file', 'error');
    }
  }

  // Save a dropped or selected file into the project's file list (CSV/JSON supported)
  async function saveFileToProject(projectId, file) {
    const proj = await ProjectStore.get(projectId);
    if (!proj) return;
    const name = (file && file.name) ? file.name : 'data.csv';
    const lower = String(name).toLowerCase();
    // Only support CSV or JSON for now (project stores textual content)
    if (!(lower.endsWith('.csv') || lower.endsWith('.json'))) {
      alertModal('Only CSV or JSON files can be added to a project at this time.', 'warning');
      return;
    }
    const text = await file.text();
    proj.data = proj.data || { csvs: [], activeCsv: null, image: null, template: 'toh', settings: {} };
    const csvs = Array.isArray(proj.data.csvs) ? proj.data.csvs : (proj.data.csvs = []);
    const existingIdx = csvs.findIndex(f => f && f.name === name);
    if (existingIdx >= 0) {
      const overwrite = await confirmAsync(`A file named "${name}" already exists in this project. Overwrite it?`, { type: 'destructive', confirmText: 'Overwrite', cancelText: 'Cancel' });
      if (!overwrite) return;
      csvs[existingIdx] = { name, text };
    } else {
      csvs.push({ name, text });
    }
    if (!proj.data.activeCsv) proj.data.activeCsv = name;
    await ProjectStore.saveSnapshot(projectId, proj.data);
    refreshList();
    if (window.showToast) window.showToast(`${lower.endsWith('.json') ? 'JSON' : 'CSV'} added to project`, 'success'); else alertModal('File added to project', 'success');
  }

  async function onSetActiveFile(projectId, fileName) {
    try {
      const proj = await ProjectStore.get(projectId);
      if (!proj || !proj.data) return;
      if (!(proj.data.csvs || []).some(f => f.name === fileName)) return;
      proj.data.activeCsv = fileName;
      await ProjectStore.saveSnapshot(projectId, proj.data);
      // Option B: Always load the project immediately and set it current
      state.currentProject = { id: proj.id, name: proj.name };
      loadSnapshotIntoUI(proj);
      refreshList();
      if (window.showToast) window.showToast(`Active file set to ${fileName} and loaded`, 'success');
    } catch (e) {
      console.error(e);
      alertModal('Failed to set active file', 'error');
    }
  }

  async function onRemoveFile(projectId, fileName) {
    try {
      const proj = await ProjectStore.get(projectId);
      if (!proj || !proj.data) return;
      const csvs = Array.isArray(proj.data.csvs) ? proj.data.csvs : (proj.data.csvs = []);
      const idx = csvs.findIndex(f => f.name === fileName);
      if (idx < 0) return;
      if (!(await confirmAsync(`Remove file "${fileName}" from this project?`, { type: 'destructive', confirmText: 'Delete', cancelText: 'Cancel' }))) return;
      csvs.splice(idx, 1);
      if (proj.data.activeCsv === fileName) {
        proj.data.activeCsv = csvs[0] ? csvs[0].name : null;
      }
      await ProjectStore.saveSnapshot(projectId, proj.data);
      // If this project is loaded and we changed active, reflect into UI
      if (state.currentProject && state.currentProject.id === projectId) {
        loadSnapshotIntoUI(proj);
      }
      refreshList();
    } catch (e) {
      console.error(e);
      alertModal('Failed to remove file', 'error');
    }
  }

  async function onRenameFile(projectId, oldName) {
    try {
      const proj = await ProjectStore.get(projectId);
      if (!proj || !proj.data) return;
      const csvs = Array.isArray(proj.data.csvs) ? proj.data.csvs : (proj.data.csvs = []);
      const idx = csvs.findIndex(f => f.name === oldName);
      if (idx < 0) return;

      // Ask for new name (default to current)
      let inputName = await promptAsync('Rename file to:', oldName, { title: 'Rename File' }).catch(() => null);
      if (!inputName) return; // canceled
      inputName = String(inputName).trim();
      if (!inputName) return;

      // Preserve extension if user omitted it
      const origExtMatch = oldName.match(/\.[^.]+$/);
      const origExt = origExtMatch ? origExtMatch[0] : '';
      const hasExt = /\.[^.]+$/.test(inputName);
      let newName = hasExt ? inputName : (origExt ? inputName + origExt : inputName);

      // Normalize case for comparison
      const targetLower = newName.toLowerCase();
      const exists = csvs.some((f, i) => i !== idx && f && f.name && f.name.toLowerCase() === targetLower);
      if (exists) {
        alertModal('A file with that name already exists in this project.', 'warning');
        return;
      }

      // No change
      if (newName === oldName) return;

      // Apply rename
      csvs[idx].name = newName;
      if (proj.data.activeCsv === oldName) {
        proj.data.activeCsv = newName;
      }
      await ProjectStore.saveSnapshot(projectId, proj.data);

      // If this project is currently loaded, update UI snapshot so active labels reflect new name
      if (state.currentProject && state.currentProject.id === projectId) {
        // Reload snapshot into UI to refresh badges and file info
        loadSnapshotIntoUI(proj);
      }
      refreshList();
      if (window.showToast) window.showToast(`Renamed to ${newName}`, 'success'); else alertModal(`Renamed to ${newName}`, 'success');
    } catch (e) {
      console.error(e);
      alertModal('Failed to rename file', 'error');
    }
  }

  // ============= Project Export / Import (JSON) ============= /* added by Cascade */
  async function onExportProjectJson() {
    try {
      const items = await ProjectStore.list();
      if (!items || items.length === 0) {
        return alertModal('No projects to export. Create or load a project first.', 'warning');
      }

      // Prefer rich modal with dropdown + Export All toggle
      let chosenId = null;
      let exportAll = false;

      if (window.Modal && typeof Modal.confirm === 'function') {
        const optionsHtml = items.map(p => `<option value="${p.id}">${p.name}</option>`).join('');
        const content = `
          <div class="tf-field">
            <label class="tf-label" for="__tfExportSelect">Choose a project to export</label>
            <div class="tf-select-wrap">
              <select id="__tfExportSelect" class="tf-select">${optionsHtml}</select>
            </div>
          </div>
          <div class="tf-field">
            <label class="tf-checkbox">
              <input type="checkbox" id="__tfExportAllChk" /> Export all projects
            </label>
          </div>`;

        await new Promise((resolve, reject) => {
          const modal = Modal.confirm({
            title: 'Export Project(s)',
            content,
            confirmText: 'Export',
            cancelText: 'Cancel',
            onConfirm: () => {
              const sel = document.getElementById('__tfExportSelect');
              const all = document.getElementById('__tfExportAllChk');
              exportAll = !!(all && all.checked);
              chosenId = sel && sel.value;
              resolve();
            },
            onCancel: () => reject(new Error('Canceled'))
          });
          // Wire checkbox to disable/enable select for clarity
          modal.show();
          setTimeout(() => {
            try {
              const sel = document.getElementById('__tfExportSelect');
              const all = document.getElementById('__tfExportAllChk');
              if (all && sel) {
                const sync = () => sel.disabled = !!all.checked;
                all.addEventListener('change', sync);
                sync();
              }
            } catch (_) {}
          }, 0);
        });
      } else {
        // Fallback prompt: allow typing 'all' to export all, otherwise choose by name
        const names = items.map(p => p.name).join(', ');
        const val = await promptAsync('Export which project? Type a name or "all" to export all.\n' + names, items[0].name).catch(() => null);
        if (!val) return; // canceled
        if (String(val).trim().toLowerCase() === 'all') exportAll = true; else {
          const found = items.find(p => p.name.toLowerCase() === String(val).trim().toLowerCase());
          if (!found) return alertModal('Project not found.', 'warning');
          chosenId = found.id;
        }
      }

      // Build payload(s)
      const buildPayload = (proj) => ({
        id: proj.id,
        name: proj.name,
        description: proj.description || '',
        createdAt: proj.createdAt,
        updatedAt: proj.updatedAt,
        schemaVersion: proj.schemaVersion || 1,
        data: proj.data || { csvs: [], activeCsv: null, image: null, template: 'toh', settings: {} }
      });

      if (exportAll) {
        const all = await Promise.all(items.map(p => ProjectStore.get(p.id)));
        const payloads = all.filter(Boolean).map(buildPayload);
        const stamp = (() => { const d = new Date(); const pad = (n)=> String(n).padStart(2,'0'); return `${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}`; })();
        const filename = `tileforge-projects-${stamp}.tileforge.json`;
        downloadTextFile(filename, JSON.stringify(payloads, null, 2), 'application/json;charset=utf-8');
        if (window.showToast) window.showToast(`Exported ${payloads.length} projects`, 'success'); else alertModal(`Exported ${payloads.length} projects`, 'success');
        return;
      }

      // Single export (default: currentProject if set, else chosen)
      let targetId = chosenId;
      if (!targetId && state.currentProject && state.currentProject.id) targetId = state.currentProject.id;
      if (!targetId) targetId = items[0].id;
      const proj = await ProjectStore.get(targetId);
      if (!proj) return alertModal('Project not found', 'warning');
      const payload = buildPayload(proj);
      const safeName = (proj.name || 'TileForgeProject').replace(/[^a-z0-9._-]+/gi, '_');
      const filename = `${safeName}.tileforge.json`;
      downloadTextFile(filename, JSON.stringify(payload, null, 2), 'application/json;charset=utf-8');
      if (window.showToast) window.showToast('Project exported', 'success'); else alertModal('Project exported', 'success');
    } catch (e) {
      if (e && e.message === 'Canceled') return;
      console.error(e);
      alertModal('Export failed', 'error');
    }
  }

  function validateImportedProject(obj) {
    if (!obj || typeof obj !== 'object') return { ok: false, reason: 'Not an object' };
    if (!obj.name || typeof obj.name !== 'string') return { ok: false, reason: 'Missing name' };
    if (!obj.data || typeof obj.data !== 'object') return { ok: false, reason: 'Missing data block' };
    const d = obj.data;
    if (!Array.isArray(d.csvs)) return { ok: false, reason: 'data.csvs must be an array' };
    for (const f of d.csvs) {
      if (!f || typeof f !== 'object' || typeof f.name !== 'string' || typeof f.text !== 'string') {
        return { ok: false, reason: 'Each file must have name and text (string)' };
      }
    }
    return { ok: true };
  }

  async function onImportProjectJson() {
    try {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'application/json,.json';
      input.onchange = async () => {
        const file = input.files && input.files[0];
        if (!file) return;
        let text = '';
        try { text = await file.text(); } catch (_) { return alertModal('Failed to read file', 'error'); }
        let parsed;
        try { parsed = JSON.parse(text); } catch (_) { return alertModal('Invalid JSON file', 'error'); }
        const items = Array.isArray(parsed) ? parsed : [parsed];
        const imported = [];
        for (const obj of items) {
          const v = validateImportedProject(obj);
          if (!v.ok) { console.warn('Invalid project skipped:', v.reason); continue; }
          try {
            const rec = await ProjectStore.create(obj.name, obj.data, obj.description || '');
            imported.push(rec);
          } catch (err) {
            console.error('Failed to import project', err);
          }
        }
        if (imported.length === 0) {
          return alertModal('No valid projects found in file.', 'warning');
        }
        if (imported.length === 1) {
          const rec = imported[0];
          state.currentProject = { id: rec.id, name: rec.name };
          const proj = await ProjectStore.get(rec.id);
          if (proj) loadSnapshotIntoUI(proj);
        }
        refreshList();
        if (window.showToast) window.showToast(`Imported ${imported.length} project${imported.length > 1 ? 's' : ''}`, 'success'); else alertModal(`Imported ${imported.length} project(s)`, 'success');
      };
      input.click();
    } catch (e) {
      console.error(e);
      alertModal('Import failed', 'error');
    }
  }

  function bindToolbar() {
    const createBtn = document.getElementById('projectCreateBtn');
    if (createBtn) createBtn.addEventListener('click', onNew);
    // added by Cascade: Project Export/Import wiring
    const exportBtn = document.getElementById('projectExportBtn');
    if (exportBtn) exportBtn.addEventListener('click', onExportProjectJson);
    const importBtn = document.getElementById('projectImportBtn');
    if (importBtn) importBtn.addEventListener('click', onImportProjectJson);
  }

  document.addEventListener('DOMContentLoaded', initOnce);

  window.ProjectUI = { initOnce, refreshList, onSave, onCloneActiveFile, onNewWithProjectPicker, onNew, onExportProjectJson, onImportProjectJson };
})();
