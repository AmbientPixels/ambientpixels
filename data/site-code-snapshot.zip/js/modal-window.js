// modal-window.js – Ambient Pixels Modal Controls
