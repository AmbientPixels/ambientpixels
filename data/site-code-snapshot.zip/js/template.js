// template.js — Homepage Status HUD + Quote Refresh

