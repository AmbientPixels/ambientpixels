// Nova’s Meme Maker Logic
console.log('Nova Meme Maker ready.');