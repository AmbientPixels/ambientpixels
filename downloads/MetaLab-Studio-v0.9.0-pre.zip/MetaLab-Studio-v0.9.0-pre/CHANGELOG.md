# MetaLab Studio - Changelog

## [v0.9.0-pre] - 2025-04-25

### 🚀 First Public Offline Release (Nebula Edition)

- Initial launch of **MetaLab Studio (Offline Version)**.
- Core Features:
  - Drag-and-drop support for `.json`, `.xml`, and `.txt` files.
  - Detailed View (nested, property-style) and Table View (flat key/value display).
  - Pretty Print toggle for easy reading of raw files.
  - File Comparison Mode (side-by-side compare).
  - Inline Search (with optional case sensitivity).
  - File Info panel (size, modified date, key counts).
  - Undo / Redo history stack.
  - Save/load session state (JSON).
  - Export to CSV / JSON / XML formats.
  - Theme switcher: Dark, Light, High Contrast.
- Included sample files: `test.json` and `test.xml`.
- Fully standalone — no internet connection required.

### 🔥 Known "pre-release quirks"

- Minor layout adjustments still in progress for super tiny screens (mobile optimization TBD).
- Validation checks are basic — custom rules may be added in future builds.
- No cloud sync (by design — this is an offline tool).

---

**Notes**:
- This is the **offline** version.  
- A separate **online** version is available at [AmbientPixels.ai](https://ambientpixels.ai/tools/meta-lab-studio.html) *(subject to updates)*.

---

*Built with caffeine, chaos, and a love for clean data.*
