# MetaLab Studio
_A lightweight, browser-based JSON/XML Metadata QC Tool._

**Version:** v0.9.0-pre (Nebula)  
**Status:** Pre-Release

➡️ For the latest version and updates, visit: https://ambientpixels.ai/tools/meta-lab-studio.html


---

## 🚀 Features
- Drag and drop JSON, XML, or TXT files
- Automatic format detection and parsing
- Pretty print toggle for readable output
- Validate basic structures (title/version checks)
- Compare two files side-by-side
- Switch between Detailed View and Table View
- Export to CSV, JSON, or XML
- Save/load sessions
- Dark, Light, and High Contrast themes
- Full search with case-sensitive option
- Full undo/redo history

---

## 🛠️ Getting Started

1. Open `index.html` in your browser.
2. Drag a `.json`, `.xml`, or `.txt` file into the input area — parsing begins automatically.
3. Use the control buttons to validate, compare, export, or customize your view.

✅ No installation required.  
✅ 100% client-side.  
✅ Works offline.

---

## 📂 Folder Structure

MetaLab-Studio-v0.9.0-pre/ ├── index.html ├── css/ │ └── meta-lab-studio.css ├── js/ │ └── meta-lab-studio.js ├── README.md ├── TECHNICAL-DOC.md ├── CHANGELOG.md ├── LICENSE.txt


---

## ⚠️ Known Limitations
- Basic rule-based validation (no schema support yet)
- Large files may slow rendering
- XML parsing relies on browser DOMParser (error messages may vary)

---

## 📋 License
© 2025 Ambient Pixels. All rights reserved.  
See `LICENSE.txt` for details.


