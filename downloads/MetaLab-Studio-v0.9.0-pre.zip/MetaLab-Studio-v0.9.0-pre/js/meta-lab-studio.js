// MetaLab Studio - Core JavaScript
// Version: v0.9.0-pre (Nebula)

let parsedData = [];
let isTableView = false;
let isPrettyPrint = false;
let currentFileIndex = 0;
let originalOutput = '';
let history = [];
let redoStack = [];
let compareMode = false;
let compareIndices = [];
const textarea = document.getElementById('inputData');
const statusDiv = document.getElementById('status');

// --- Event Listeners ---
textarea.addEventListener('dragover', (e) => {
    e.preventDefault();
    textarea.classList.add('dragover');
    statusDiv.textContent = 'Drop files to add them!';
});

textarea.addEventListener('dragleave', () => {
    textarea.classList.remove('dragover');
    statusDiv.textContent = parsedData.length ? `${parsedData.length} file(s) loaded—drop more to append` : 'Ready to load files';
});

textarea.addEventListener('drop', (e) => {
    e.preventDefault();
    textarea.classList.remove('dragover');
    const files = Array.from(e.dataTransfer.files).filter(file => /\.(json|xml|txt)$/i.test(file.name));
    if (files.length === 0) {
        statusDiv.textContent = 'Only .json, .xml, or .txt files supported';
        statusDiv.style.color = '#ff6b6b';
        return;
    }
    readFiles(files);
    setTimeout(parseAuto, 0);
});

textarea.addEventListener('input', () => setTimeout(parseAuto, 0));

// --- Core Processing Functions ---
function readFiles(files) {
    let completed = 0;
    statusDiv.textContent = `Loading ${files.length} file(s)...`;
    files.forEach((file, index) => {
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const content = e.target.result.trim();
                let data;
                if (content.startsWith('<')) {
                    const parser = new DOMParser();
                    const xmlDoc = parser.parseFromString(content, "text/xml");
                    if (xmlDoc.getElementsByTagName("parsererror").length > 0) throw new Error("Invalid XML");
                    data = xmlToJson(xmlDoc.documentElement);
                } else {
                    data = JSON.parse(content);
                }
                const formattedContent = isPrettyPrint ? JSON.stringify(data, null, 2) : JSON.stringify(data);
                parsedData.push({ name: file.name, data, raw: formattedContent, size: file.size, lastModified: file.lastModified });
            } catch (e) {
                parsedData.push({ name: file.name, error: e.message, raw: e.target.result, size: file.size, lastModified: file.lastModified });
            }
            completed++;
            if (completed === files.length) {
                saveHistory();
                updateTextarea();
                renderTabs();
                showFile(parsedData.length - 1);
                statusDiv.textContent = `${parsedData.length} file(s) loaded—drop more to append`;
                statusDiv.style.color = '#89c2d9';
                document.getElementById('exportSelect').disabled = false;
                document.getElementById('toggleCheckbox').disabled = false;
                document.getElementById('compareBtn').disabled = parsedData.length < 2;
            }
        };
        reader.readAsText(file);
    });
}

function parseAuto() {
    const input = textarea.value.trim();
    parsedData = [];
    const outputDiv = document.getElementById('output');
    const exportSelect = document.getElementById('exportSelect');
    const toggleCheckbox = document.getElementById('toggleCheckbox');
    outputDiv.innerHTML = '';
    statusDiv.textContent = 'Processing...';
    try {
        if (input.startsWith('<')) {
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(input, "text/xml");
            if (xmlDoc.getElementsByTagName("parsererror").length > 0) throw new Error("Invalid XML format");
            const data = xmlToJson(xmlDoc.documentElement);
            parsedData.push({ name: 'Input', data, raw: isPrettyPrint ? JSON.stringify(data, null, 2) : JSON.stringify(data) });
        } else if (input.startsWith('{') || input.startsWith('[')) {
            const data = JSON.parse(input);
            parsedData.push({ name: 'Input', data, raw: isPrettyPrint ? JSON.stringify(data, null, 2) : JSON.stringify(data) });
        } else {
            throw new Error("Unable to detect format (must be JSON or XML)");
        }
        saveHistory();
        renderTabs();
        showFile(0);
        updateTextarea();
        statusDiv.textContent = '1 file processed—drop more to append';
        exportSelect.disabled = false;
        toggleCheckbox.disabled = false;
        document.getElementById('compareBtn').disabled = parsedData.length < 2;
    } catch (e) {
        outputDiv.innerHTML = `<p style="color: #ff6b6b;">Parse Error: ${escapeHtml(e.message)}</p>`;
        statusDiv.textContent = 'Error processing data';
        statusDiv.style.color = '#ff6b6b';
        exportSelect.disabled = true;
        toggleCheckbox.disabled = true;
        parsedData = [];
    }
}

function xmlToJson(xml) {
    const obj = {};
    if (xml.nodeType === 1) {
        if (xml.attributes.length > 0) {
            obj["@attributes"] = {};
            for (let j = 0; j < xml.attributes.length; j++) {
                const attribute = xml.attributes[j];
                obj["@attributes"][attribute.nodeName] = attribute.nodeValue;
            }
        }
    } else if (xml.nodeType === 3) {
        return xml.nodeValue.trim();
    }
    if (xml.hasChildNodes()) {
        for (let i = 0; i < xml.childNodes.length; i++) {
            const item = xml.childNodes[i];
            const nodeName = item.nodeName;
            if (nodeName === "#text" && item.nodeValue.trim() === "") continue;
            const childValue = xmlToJson(item);
            if (typeof obj[nodeName] === "undefined") {
                obj[nodeName] = childValue;
            } else {
                if (!Array.isArray(obj[nodeName])) {
                    obj[nodeName] = [obj[nodeName]];
                }
                obj[nodeName].push(childValue);
            }
        }
    }
    return obj;
}

function updateTextarea() {
    textarea.value = parsedData.map(item => {
        if (item.error) {
            return `// Error in ${item.name}: ${item.error}\n${item.raw}`;
        }
        return item.raw || (item.data ? (isPrettyPrint ? JSON.stringify(item.data, null, 2) : JSON.stringify(item.data)) : '');
    }).join('\n\n');
}


// --- Validation and History Management ---
function validateData() {
    if (!parsedData[currentFileIndex] || parsedData[currentFileIndex].error) {
        document.getElementById('output').innerHTML = '<p style="color: #ff6b6b;">No valid data to validate</p>';
        return;
    }
    const data = parsedData[currentFileIndex].data;
    let errors = [];
    if (!data.title) errors.push("Missing required field: title");
    if (data.version && typeof data.version !== "number") errors.push("Version must be a number");
    const outputDiv = document.getElementById('output');
    outputDiv.innerHTML = errors.length ?
        `<p style="color: #ff6b6b;">Validation Errors:<br>${errors.join('<br>')}</p>` :
        '<p style="color: #89c2d9;">Data is valid</p>';
}

function saveHistory() {
    history.push({ data: [...parsedData], text: textarea.value });
    redoStack = [];
}

function undo() {
    if (history.length > 1) {
        redoStack.push(history.pop());
        const state = history[history.length - 1];
        parsedData = state.data;
        textarea.value = state.text;
        renderTabs();
        showFile(currentFileIndex);
    }
}

function redo() {
    if (redoStack.length) {
        const state = redoStack.pop();
        history.push(state);
        parsedData = state.data;
        textarea.value = state.text;
        renderTabs();
        showFile(currentFileIndex);
    }
}
// --- Compare Mode ---
function toggleCompare() {
    compareMode = !compareMode;
    const outputDiv = document.getElementById('output');
    outputDiv.classList.toggle('compare-mode');
    if (compareMode && parsedData.length >= 2) {
        compareIndices = [currentFileIndex, (currentFileIndex + 1) % parsedData.length];
        showCompare();
    } else {
        showFile(currentFileIndex);
    }
}

function showCompare() {
    const outputDiv = document.getElementById('output');
    outputDiv.innerHTML = '';
    compareIndices.forEach(index => {
        const item = parsedData[index];
        const div = document.createElement('div');
        div.innerHTML = item.error ?
            `<p style="color: #ff6b6b;">Error in ${escapeHtml(item.name)}: ${escapeHtml(item.error)}</p>` :
            (isTableView ? renderTable(item.data) : renderJSON(item.data));
        outputDiv.appendChild(div);
    });
}

// --- File and Tab Management ---
function renderTabs() {
    const tabContainer = document.getElementById('tabContainer');
    tabContainer.innerHTML = '';
    parsedData.forEach((item, index) => {
        const tab = document.createElement('div');
        tab.className = `tab ${index === currentFileIndex ? 'active' : ''}`;
        tab.innerHTML = `${escapeHtml(item.name)} <span class="tab-close" onclick="closeTab(${index}, event)">×</span>`;
        tab.onclick = (e) => {
            if (e.target.className !== 'tab-close') showFile(index);
        };
        tabContainer.appendChild(tab);
    });
}

function closeTab(index, event) {
    event.stopPropagation();
    saveHistory();
    parsedData.splice(index, 1);
    if (parsedData.length === 0) {
        clearInput();
    } else {
        currentFileIndex = Math.min(index, parsedData.length - 1);
        updateTextarea();
        renderTabs();
        showFile(currentFileIndex);
        statusDiv.textContent = `${parsedData.length} file(s) loaded—drop more to append`;
        document.getElementById('compareBtn').disabled = parsedData.length < 2;
    }
}

function showFile(index) {
    currentFileIndex = index;
    const outputDiv = document.getElementById('output');
    const item = parsedData[index];
    outputDiv.classList.remove('compare-mode');
    if (!item || item.error) {
        outputDiv.innerHTML = `<p style="color: #ff6b6b;">${item ? 'Error in ' + escapeHtml(item.name) + ': ' + escapeHtml(item.error) : 'No data available'}</p>`;
    } else {
        outputDiv.innerHTML = isTableView ? renderTable(item.data) : renderJSON(item.data);
    }
    originalOutput = outputDiv.innerHTML;
    renderTabs();
    filterOutput();
    updateFileInfo(item);
}

// --- Renderers ---
function renderJSON(data, level = 0) {
    let html = '<div class="section">';
    if (level === 0) html += '<h2>Data Structure</h2>';
    for (const [key, value] of Object.entries(data)) {
        if (key === '@attributes') {
            for (const [attrKey, attrValue] of Object.entries(value)) {
                html += `<div class="property"><label>${escapeHtml(attrKey)} (attr):</label> ${escapeHtml(String(attrValue))}</div>`;
            }
        } else if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
            html += `<div class="property"><label>${escapeHtml(key)}:</label> ${escapeHtml(String(value))}</div>`;
        } else if (Array.isArray(value) || (typeof value === 'object' && value !== null)) {
            html += `<div class="property"><label>${escapeHtml(key)}:</label></div>`;
            html += '<div class="nested">';
            if (Array.isArray(value)) {
                value.forEach((item, index) => {
                    html += `<h3>${escapeHtml(key)} [${index}]</h3>`;
                    html += renderJSON(item, level + 1);
                });
            } else {
                html += renderJSON(value, level + 1);
            }
            html += '</div>';
        }
    }
    html += '</div>';
    return html;
}

function renderTable(data) {
    let html = '<table><tr><th>Key</th><th>Value</th><th>Attributes</th></tr>';
    const rows = [];

    function flattenData(obj, parentKey = '') {
        for (const [key, value] of Object.entries(obj)) {
            const fullKey = parentKey ? `${parentKey}.${key}` : key;
            let attrs = '';
            if (key === '@attributes') continue;
            if (obj['@attributes']) {
                attrs = Object.entries(obj['@attributes']).map(([k, v]) => `${escapeHtml(k)}=${escapeHtml(v)}`).join(', ');
            }
            if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
                rows.push([fullKey, String(value), attrs]);
            } else if (Array.isArray(value)) {
                value.forEach((item, index) => flattenData(item, `${fullKey}[${index}]`));
            } else if (typeof value === 'object' && value !== null) {
                flattenData(value, fullKey);
            }
        }
    }

    flattenData(data);
    rows.forEach(([key, value, attributes]) => {
        html += `<tr><td>${escapeHtml(key)}</td><td>${escapeHtml(value)}</td><td>${escapeHtml(attributes)}</td></tr>`;
    });
    if (rows.length === 0) {
        html += '<tr><td colspan="3">No data to display</td></tr>';
    }
    html += '</table>';
    return html;
}

// --- Exporting ---
function exportData(format) {
    if (parsedData.length === 0 || !parsedData[currentFileIndex] || parsedData[currentFileIndex].error) {
        alert('No valid data to export.');
        return;
    }
    const item = parsedData[currentFileIndex];
    let content, type, extension;

    switch (format) {
        case 'csv':
            const rows = ['"Key","Value","Attributes"'];
            function flattenData(obj, parentKey = '') {
                for (const [key, value] of Object.entries(obj)) {
                    const fullKey = parentKey ? `${parentKey}.${key}` : key;
                    let attrs = '';
                    if (key === '@attributes') continue;
                    if (obj['@attributes']) {
                        attrs = Object.entries(obj['@attributes']).map(([k, v]) => `${k}=${v}`).join(', ');
                    }
                    if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
                        rows.push(`"${fullKey.replace(/"/g, '""')}","${String(value).replace(/"/g, '""')}","${attrs.replace(/"/g, '""')}"`);
                    } else if (Array.isArray(value)) {
                        value.forEach((item, index) => flattenData(item, `${fullKey}[${index}]`));
                    } else if (typeof value === 'object' && value !== null) {
                        flattenData(value, fullKey);
                    }
                }
            }
            flattenData(item.data);
            content = rows.join('\n');
            type = 'text/csv';
            extension = 'csv';
            break;
        case 'json':
            content = isPrettyPrint ? JSON.stringify(item.data, null, 2) : JSON.stringify(item.data);
            type = 'application/json';
            extension = 'json';
            break;
        case 'xml':
            content = jsonToXml(item.data);
            type = 'application/xml';
            extension = 'xml';
            break;
        default:
            return;
    }
    const blob = new Blob([content], { type });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${item.name.split('.')[0] || 'metadata'}.${extension}`;
    a.click();
    window.URL.revokeObjectURL(url);
    document.getElementById('exportSelect').value = '';
}

// --- Support Functions ---
function escapeHtml(unsafe) {
    if (unsafe === null || unsafe === undefined) return '';
    return String(unsafe)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function filterOutput() {
    const searchTerm = document.getElementById('searchInput').value;
    const caseSensitive = document.getElementById('caseSensitive').checked;
    const outputDiv = document.getElementById('output');
    if (!parsedData.length || !originalOutput) return;

    const term = caseSensitive ? searchTerm : searchTerm.toLowerCase();
    if (isTableView) {
        const table = document.createElement('table');
        table.innerHTML = originalOutput;
        const rows = Array.from(table.getElementsByTagName('tr'));
        const filteredRows = rows.filter(row => {
            const cells = row.getElementsByTagName('td');
            return Array.from(cells).some(cell =>
                caseSensitive ? cell.textContent.includes(term) : cell.textContent.toLowerCase().includes(term)
            );
        });
        outputDiv.innerHTML = '<table>' + filteredRows.map(row => row.outerHTML).join('') + '</table>';
    } else {
        outputDiv.innerHTML = originalOutput;
        const properties = outputDiv.getElementsByClassName('property');
        Array.from(properties).forEach(prop => {
            const text = caseSensitive ? prop.textContent : prop.textContent.toLowerCase();
            prop.style.display = text.includes(term) ? '' : 'none';
        });
    }
}

function updateFileInfo(item) {
    const fileInfo = document.getElementById('fileInfo');
    if (!item) {
        fileInfo.innerHTML = '<h3>File Info</h3><p>No file selected</p>';
        return;
    }
    const sizeKB = item.size ? (item.size / 1024).toFixed(2) + ' KB' : 'N/A';
    const lastMod = item.lastModified ? new Date(item.lastModified).toLocaleString() : 'N/A';
    const keyCount = item.data ? Object.keys(flattenObject(item.data)).length : 0;
    fileInfo.innerHTML = `
        <h3>File Info</h3>
        <p><strong>Name:</strong> ${escapeHtml(item.name)}</p>
        <p><strong>Size:</strong> ${sizeKB}</p>
        <p><strong>Last Modified:</strong> ${lastMod}</p>
        <p><strong>Keys:</strong> ${keyCount}</p>
    `;
}

function flattenObject(obj, parent = '', res = {}) {
    for (const [key, value] of Object.entries(obj)) {
        const propName = parent ? `${parent}.${key}` : key;
        if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
            flattenObject(value, propName, res);
        } else {
            res[propName] = value;
        }
    }
    return res;
}

