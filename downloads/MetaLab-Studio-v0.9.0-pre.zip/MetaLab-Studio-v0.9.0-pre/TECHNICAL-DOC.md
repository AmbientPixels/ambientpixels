# MetaLab Studio - Technical Documentation

**Version:** v0.9.0-pre  
**Release Date:** April 25, 2025

---

## 🛠️ Code Structure

| File | Purpose |
|:-----|:--------|
| index.html | Core UI structure and interface layout |
| css/meta-lab-studio.css | All styling: layout, theming, typography |
| js/meta-lab-studio.js | Core logic: file parsing, validation, view switching, exporting |

---

## ⚙️ Main Functionalities

- **parseAuto()** — Parses incoming JSON or XML into a structured object
- **validateData()** — Checks basic field validation (e.g., `title`, `version`)
- **toggleCompare()** — Activates side-by-side comparison view
- **exportData()** — Exports current file as CSV, JSON, or XML
- **applyTheme()** — Switches between Dark, Light, High Contrast modes
- **saveState()/loadState()** — Save and restore working sessions

---

## 🔍 Special Features

- **Pretty Print Toggle:** Formats JSON/XML for easy reading.
- **Undo/Redo System:** History saved per session.
- **Tab Management:** Manage multiple open files at once.
- **Full Search:** Live filtering of displayed keys/values.

---

## 📈 Roadmap (Post 1.0)

- Full JSON Schema validation support
- Custom validation rule plugins
- Visual diff highlighting
- Larger dataset optimization (virtual rendering)

---

## 📋 Requirements
- Modern browser (Chrome, Edge Chromium, Firefox, Safari)
- No server dependency (local execution)

---

## 📜 License
This tool is © 2025 Ambient Pixels.  
For licensing, redistribution, or custom work inquiries, contact [ambientpixels.ai](https://ambientpixels.ai).
