const { BlobServiceClient } = require('@azure/storage-blob');

module.exports = async function (context, req) {
    // ENHANCED DEBUGGING: Log detailed information about the request
    context.log('========== PUBLISH DEBUG LOG START ==========');
    context.log(`Function triggered at: ${new Date().toISOString()}`);
    context.log(`Request method: ${req.method}`);
    context.log(`Request URL: ${req.url}`);
    context.log(`Route parameters: ${JSON.stringify(req.params)}`);
    context.log(`Query string: ${JSON.stringify(req.query)}`);
    
    // Log all headers in lowercase for easier debugging of case sensitivity issues
    const lowerCaseHeaders = {};
    for (const headerName in req.headers) {
        lowerCaseHeaders[headerName.toLowerCase()] = req.headers[headerName];
    }
    context.log(`ALL REQUEST HEADERS (lowercase): ${JSON.stringify(lowerCaseHeaders)}`);
    
    // Specifically check for user ID in all possible locations
    context.log(`x-user-id header (lowercase): ${lowerCaseHeaders['x-user-id'] || 'NOT FOUND'}`);
    context.log(`X-User-ID header (uppercase): ${req.headers['X-User-ID'] || 'NOT FOUND'}`);
    context.log(`userId in query: ${req.query.userId || 'NOT FOUND'}`);
    context.log(`userId in body: ${req.body && req.body.userId ? req.body.userId : 'NOT FOUND'}`);
    context.log(`body content: ${JSON.stringify(req.body || {})}`);
    
    // Validate authentication - check for user ID in headers case-insensitively
    const userId = req.headers['x-user-id'] || req.headers['X-User-ID'] || req.query.userId || (req.body && req.body.userId);
    context.log(`Final resolved userId: ${userId || 'NOT RESOLVED - WILL CAUSE 401'}`);
    
    // Environment check
    context.log(`Environment check - AZURE_STORAGE_CONNECTION_STRING exists: ${!!process.env.AZURE_STORAGE_CONNECTION_STRING}`);


    if (!userId) {
        context.log.error('User ID missing from request');
        context.res = {
            status: 401,
            headers: { 'Content-Type': 'application/json' },
            body: { message: 'User not authenticated. Please sign in to publish cards.' }
        };
        return;
    }

    // Validate card ID
    const cardId = req.params.id;
    context.log(`Publishing request for card ID: ${cardId}`);
    
    if (!cardId) {
        context.log.error('Card ID is missing from the request');
        context.res = {
            status: 400,
            headers: { 'Content-Type': 'application/json' },
            body: { message: 'Card ID is required' }
        };
        return;
    }

    try {
        // Initialize Azure Blob Storage client
        const connectionString = process.env.AZURE_STORAGE_CONNECTION_STRING;
        if (!connectionString) {
            throw new Error('Azure Storage connection string not found');
        }
        
        const blobServiceClient = BlobServiceClient.fromConnectionString(connectionString);
        const containerName = 'cardforge';
        const containerClient = blobServiceClient.getContainerClient(containerName);
        
        // Create container if it doesn't exist
        try {
            await containerClient.createIfNotExists();
            context.log('Container created or already exists');
        } catch (containerError) {
            context.log.error('Error creating container:', containerError);
            throw new Error('Failed to ensure container exists');
        }
        
        // Get user's card data - first check if user blob exists
        const userBlobName = `${userId}.json`;
        const userBlobClient = containerClient.getBlockBlobClient(userBlobName);
        const userBlobExists = await userBlobClient.exists();
        
        context.log(`Looking for user blob: ${userBlobName}`);
        context.log(`User blob exists: ${userBlobExists}`);

        // If the client sent card data in the request, use that as fallback
        let cardToPublish = null;
        if (req.body && req.body.card) {
            context.log('Using card data sent from client');
            cardToPublish = req.body.card;
            
            if (cardToPublish.id !== cardId) {
                context.log.error(`Card ID mismatch: route parameter ${cardId}, but card data has ID ${cardToPublish.id}`);
                context.res = {
                    status: 400,
                    headers: { 'Content-Type': 'application/json' },
                    body: { message: 'Card ID mismatch between URL and payload' }
                };
                return;
            }
        } else {
            // Try to load card from user's blob storage
            if (!userBlobExists) {
                context.log.error(`User blob not found: ${userBlobName}`);
                
                // List available blobs for debugging
                let blobCount = 0;
                let blobList = [];
                
                try {
                    for await (const blob of containerClient.listBlobsFlat()) {
                        blobList.push(blob.name);
                        blobCount++;
                        if (blobCount >= 10) break; // List up to 10 blobs
                    }
                    context.log(`First ${blobCount} blobs in container: ${blobList.join(', ')}`);
                } catch (listError) {
                    context.log.error(`Error listing blobs: ${listError.message}`);
                }
                
                context.res = {
                    status: 404,
                    headers: { 'Content-Type': 'application/json' },
                    body: { message: `No cards found for user ${userId}` }
                };
                return;
            }

            // Download user's cards
            const userBlobDownload = await userBlobClient.download(0);
            const userCardsContent = await streamToString(userBlobDownload.readableStreamBody);
            const userCards = JSON.parse(userCardsContent);

            // Find the card to publish
            cardToPublish = userCards.find(card => card.id === cardId);
            if (!cardToPublish) {
                context.log.error(`Card not found in user's blob: ${cardId}`);
                context.res = {
                    status: 404,
                    headers: { 'Content-Type': 'application/json' },
                    body: { message: 'Card not found' }
                };
                return;
            }
        }

        // Get published cards list
        const publishedBlobName = 'published-cards.json';
        const publishedBlobClient = containerClient.getBlockBlobClient(publishedBlobName);
        const publishedBlobExists = await publishedBlobClient.exists();

        let publishedCards = [];
        if (publishedBlobExists) {
            const publishedDownload = await publishedBlobClient.download(0);
            const publishedContent = await streamToString(publishedDownload.readableStreamBody);
            publishedCards = JSON.parse(publishedContent);
        }

        // Check if card is already published
        const existingPublishedIndex = publishedCards.findIndex(card => card.id === cardId && card.userId === userId);
        
        // Prepare the published card data
        const publishedCard = {
            ...cardToPublish,
            userId: userId,
            publishedDate: new Date().toISOString(),
            views: existingPublishedIndex >= 0 ? publishedCards[existingPublishedIndex].views || 0 : 0
        };

        // Remove sensitive data that shouldn't be public
        delete publishedCard.privateNotes;
        
        // Add or update in the published cards list
        if (existingPublishedIndex >= 0) {
            // Update existing published card
            publishedCards[existingPublishedIndex] = publishedCard;
            context.log(`Updated existing published card: ${cardId}`);
        } else {
            // Add new published card
            publishedCards.push(publishedCard);
            context.log(`Published new card: ${cardId}`);
        }

        // Save updated published cards list
        await publishedBlobClient.upload(
            JSON.stringify(publishedCards),
            JSON.stringify(publishedCards).length
        );

        context.res = {
            status: 200,
            headers: { 'Content-Type': 'application/json' },
            body: { 
                message: 'Card published successfully', 
                publishedCard: publishedCard
            }
        };
    } catch (error) {
        context.log.error('Error publishing card:', error);
        context.res = {
            status: 500,
            headers: { 'Content-Type': 'application/json' },
            body: { 
                message: 'Error publishing card', 
                error: error.message 
            }
        };
    }
};

// Helper function to convert stream to string
async function streamToString(readableStream) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        readableStream.on('data', (data) => {
            chunks.push(data.toString());
        });
        readableStream.on('end', () => {
            resolve(chunks.join(''));
        });
        readableStream.on('error', reject);
    });
}
